#!/usr/bin/ksh



FIRST=$(pgrep -fl 'ctmfw' | awk '/-input/ {print $4}' | awk -F"/" '{ if ( /tmp/ )  print $8   ; else   print $7}'|  wc -l )   
SECOND=$(pgrep -fl 'ctmfw' | awk '!/-input/ {print $3}' |  awk -F"/" '{ if ( /netfs/)  print $8; else print $6}' | wc -l  )

print Total Filewatxcher count on $(hostname) is $(( FIRST + SECOND )) 


# sort output into file for comparison 
{
pgrep -fl 'ctmfw' | awk '/-input/ {print $4}' | awk -F"/" '{ if ( /tmp/ )  print $8   ; else   print $7}' 
pgrep -fl 'ctmfw' | awk '!/-input/ {print $3}' |  awk -F"/" '{ if ( /netfs/)  print $8; else print $6}'  

} | sort > /tmp/$(hostname).fw
